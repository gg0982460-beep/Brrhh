const CACHE='casa-shell-v2';
const ASSETS=['./','./index.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET') return;
 const u=new URL(e.request.url);
 if(u.origin!==location.origin) return;
 e.respondWith(caches.match(e.request).then(x=>x||fetch(e.request).then(r=>{
   if(r.ok){const c=r.clone();caches.open(CACHE).then(k=>k.put(e.request,c));}
   return r;
 }).catch(()=>caches.match('./index.html'))));
});