# Casa — Offline Music Player

Retro cream/brown local music player with PWA support and Capacitor Android packaging.

The `www` folder is the installable PWA. Music is stored locally in IndexedDB.
No account, backend, cloud database, or internet connection is required for playback.
